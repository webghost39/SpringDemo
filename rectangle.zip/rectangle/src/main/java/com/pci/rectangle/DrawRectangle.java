package com.pci.rectangle;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.function.Consumer;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * A handy class to show the result in graph.
 */
public class DrawRectangle extends JFrame
{

	public void draw(IntersectionResult result, boolean drawIntersectPoints)
	{
		if (drawIntersectPoints)
		{
			draw(result.getFirst(), result.getSecond(), result.getIntersectPoints());
		}
		else
		{
			final Point[] points = result.getIntersectRectanglePoints();
			draw(result.getFirst(), result.getSecond(),
					points == null ? null : RectangleX.fromPoints(points[0], points[1]));
		}
	}

	public void draw(RectangleX first, RectangleX second, Point[] points)
	{
		draw(first.toAwtRectangle(), second.toAwtRectangle(), g2 -> {
			if (points != null)
			{
				g2.setColor(Color.BLACK);
				for (Point point : points)
				{
					Shape circle = new Ellipse2D.Double(point.getX(), point.getY(), 5, 5);
					g2.fill(circle);
				}
			}
		});
	}

	public void draw(Rectangle first, Rectangle second, Consumer<Graphics2D> drawRectangleOrPoints)
	{
		setSize(new Dimension(888, 888));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);

		JPanel p = new JPanel()
		{
			@Override
			public void paintComponent(Graphics g)
			{
				Graphics2D g2 = (Graphics2D) g;
				g2.setStroke(new BasicStroke(3));
				g2.setColor(Color.red);
				g2.draw(first);
				g2.setColor(Color.BLUE);
				g2.draw(second);
				drawRectangleOrPoints.accept(g2);
			}
		};

		setTitle("My Rectangles");
		this.getContentPane().add(p);
	}

	public void draw(RectangleX first, RectangleX second, RectangleX intersection)
	{
		final Rectangle is = intersection == null ? null : intersection.toAwtRectangle();
		draw(first.toAwtRectangle(), second.toAwtRectangle(), g2 -> {
			if (is != null)
			{
				g2.setColor(Color.GREEN);
				g2.fill(is);
				g2.setColor(Color.BLACK);
				g2.draw(is);
			}
		});
	}
}
