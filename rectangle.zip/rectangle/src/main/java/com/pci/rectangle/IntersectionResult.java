package com.pci.rectangle;

/**
 * A class represents the result of intersection check. first, second are input two rectangles.
 * intersectRectanglePoints are the two points represent the intersection rectangle if present.
 * intersectionPoints are intersect points if present
 */
public class IntersectionResult
{
	private final RectangleX first;

	private final RectangleX second;
	private final Point[] intersectRectanglePoints;

	private final Point[] intersectPoints;

	public IntersectionResult(RectangleX first, RectangleX second, Point[] intersectRectanglePoints, Point[] intersectPoints)
	{
		this.first = first;
		this.second = second;
		this.intersectRectanglePoints = intersectRectanglePoints;
		this.intersectPoints = intersectPoints;
	}

	public Point[] getIntersectRectanglePoints()
	{
		return intersectRectanglePoints;
	}

	public Point[] getIntersectPoints()
	{
		return intersectPoints;
	}

	public RectangleX getFirst()
	{
		return first;
	}

	public RectangleX getSecond()
	{
		return second;
	}
}
