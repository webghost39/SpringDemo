package com.pci.rectangle;

import javax.swing.SwingUtilities;


public class Main
{
	public static void main(String[] arg)
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 30, 100, 100);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);

		SwingUtilities.invokeLater(() -> new DrawRectangle().draw(intersectionPoints, true));
	}
}
