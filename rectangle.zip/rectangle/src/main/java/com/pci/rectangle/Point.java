package com.pci.rectangle;

import java.util.Objects;

/**
 * A point representing a location in (x,y) coordinate space, specified in integer precision.
 */
public class Point
{
	private final int x;
	private final int y;

	/**
	 * Construct a point from x,y coordinate.
	 *
	 * @param x x coordinate
	 * @param y y coordinate
	 */
	public Point(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	/**
	 * Get x coordinate.
	 */
	public int getX()
	{
		return x;
	}

	/**
	 * Get y coordinate.
	 */
	public int getY()
	{
		return y;
	}

	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Point point = (Point) o;
		return x == point.x && y == point.y;
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(x, y);
	}

	@Override
	public String toString()
	{
		return "Point{" +
				"x=" + x +
				", y=" + y +
				'}';
	}
}
