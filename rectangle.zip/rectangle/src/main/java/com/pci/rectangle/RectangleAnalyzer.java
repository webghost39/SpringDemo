package com.pci.rectangle;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

/**
 * A utility class used to determine if two rectangle is intersection, containment or adjacency.
 */
public final class RectangleAnalyzer
{
	private RectangleAnalyzer()
	{
	}

	/**
	 * Check if two given rectangle is intersection.
	 *
	 * @param first  first rectangle
	 * @param second second rectangle
	 * @return {@link IntersectionResult}
	 */
	public static IntersectionResult findIntersectionPoints(RectangleX first, RectangleX second)
	{

		final Point[] points = getIntersectionPoints(first, second);
		int x1 = points[0].getX();
		int y1 = points[0].getY();

		int x2 = points[1].getX();
		int y2 = points[1].getY();

		final Point point1 = new Point(x1, y1);
		final Point point2 = new Point(x2, y2);

		final Point[] intersectRectanglePoints = { point1, point2 };
		final Point point3 = new Point(x1, y2);
		final Point point4 = new Point(x2, y1);
		final List<Point> pointList = Arrays.asList(first.getTopLeft(), first.getBottomRight(),
				new Point(first.getTopLeft().getX(), first.getBottomRight().getY()),
				new Point(first.getBottomRight().getX(), first.getTopLeft().getY()),
				second.getTopLeft(), second.getBottomRight(),
				new Point(second.getTopLeft().getX(), second.getBottomRight().getY()),
				new Point(second.getBottomRight().getX(), second.getTopLeft().getY()));
		final Point[] intersectPoints = Stream.of(point1, point2, point3, point4).filter(s -> !pointList.contains(s)).toArray(Point[]::new);

		//no intersection
		if (x1 > x2 || y1 > y2)
		{
			return new IntersectionResult(first, second, null, null);
		}
		//overlap on one point
		else if (Objects.equals(points[0], points[1]))
		{
			return new IntersectionResult(first, second, intersectRectanglePoints, null);
		}
		//Adjacency
		else if (x1 == x2 || y1 == y2)
		{
			return new IntersectionResult(first, second, intersectRectanglePoints, null);
		}

		final RectangleX rectangleX = RectangleX.fromPoints(points[0], points[1]);
		//Containment
		if (Objects.equals(rectangleX, first) || Objects.equals(rectangleX, second))
		{
			return new IntersectionResult(first, second, intersectRectanglePoints, null);
		}

		return new IntersectionResult(first, second, intersectRectanglePoints, intersectPoints);
	}

	/**
	 * Check if two given rectangle is containment.
	 *
	 * @param first  first rectangle
	 * @param second second rectangle
	 * @return boolean result, true means is containment
	 */
	public static boolean isContainment(RectangleX first, RectangleX second)
	{
		final Point[] points = getIntersectionPoints(first, second);
		final RectangleX rectangleX = new RectangleX(points[0], points[1]);
		return Objects.equals(rectangleX, first) || Objects.equals(rectangleX, second);
	}

	/**
	 * Check if two given rectangle is adjacency.
	 *
	 * @param first  first rectangle
	 * @param second second rectangle
	 * @return boolean result, true means is adjacency
	 */
	public static boolean isAdjacency(RectangleX first, RectangleX second)
	{
		final Point[] points = getIntersectionPoints(first, second);
		int x1 = points[0].getX();
		int y1 = points[0].getY();

		int x2 = points[1].getX();
		int y2 = points[1].getY();

		return x1 == x2 || y1 == y2;
	}

	private static Point[] getIntersectionPoints(RectangleX first, RectangleX second)
	{
		int x1 = Math.max(first.getTopLeft().getX(), second.getTopLeft().getX());
		int y1 = Math.max(first.getTopLeft().getY(), second.getTopLeft().getY());

		int x2 = Math.min(first.getBottomRight().getX(), second.getBottomRight().getX());
		int y2 = Math.min(first.getBottomRight().getY(), second.getBottomRight().getY());

		return new Point[] { new Point(x1, y1), new Point(x2, y2) };
	}
}
