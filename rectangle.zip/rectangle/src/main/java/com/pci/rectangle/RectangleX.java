package com.pci.rectangle;


import java.util.Objects;

/**
 * A Rectangle specifies an area in a coordinate space that is enclosed by the Rectangle object's
 * top-left point topLeft and bottom-right point bottomRight in the coordinate space.
 */
public class RectangleX
{
	private final Point topLeft;
	private final Point bottomRight;

	/**
	 * Construct a RectangleX from {@link Point}.
	 *
	 * @param topLeft     top-left point
	 * @param bottomRight top-right point
	 */
	RectangleX(Point topLeft, Point bottomRight)
	{
		this.topLeft = topLeft;
		this.bottomRight = bottomRight;
	}

	/**
	 * Factory method to create {@link RectangleX} from two points.
	 *
	 * @param topLeft     top-left point
	 * @param bottomRight bottom right point
	 * @return created {@link  RectangleX}
	 */
	public static RectangleX fromPoints(Point topLeft, Point bottomRight)
	{
		if (bottomRight.getX() < topLeft.getX() || bottomRight.getY() < topLeft.getY())
		{
			throw new IllegalArgumentException("Illegal rectangle.");
		}
		return new RectangleX(topLeft, bottomRight);
	}

	/**
	 * Factory method to create {@link RectangleX} from two points coordinate.
	 *
	 * @param x1 top-left point's x
	 * @param y1 top-left point's y
	 * @param x2 bottom-right point's x
	 * @param y2 bottom-right point's y
	 * @return created {@link  RectangleX}
	 */
	public static RectangleX fromPoints(int x1, int y1, int x2, int y2)
	{
		return fromPoints(new Point(x1, y1), new Point(x2, y2));
	}

	/**
	 * Convert {@link RectangleX} to {@link java.awt.Rectangle}.
	 */
	public java.awt.Rectangle toAwtRectangle()
	{
		return new java.awt.Rectangle(topLeft.getX(), topLeft.getY(), bottomRight.getX() - topLeft.getX(), bottomRight.getY() - topLeft.getY());
	}

	/**
	 * Get top-left point.
	 */
	public Point getTopLeft()
	{
		return topLeft;
	}

	/**
	 * Get bottom-right point.
	 */
	public Point getBottomRight()
	{
		return bottomRight;
	}

	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		RectangleX that = (RectangleX) o;
		return topLeft.equals(that.topLeft) && Objects.equals(bottomRight, that.bottomRight);
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(topLeft, bottomRight);
	}
}
