package com.pci.rectangle;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RectangleAnalyzerTest
{
	@Test
	void test_overlap_on_one_point_no_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 90, 80, 100);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);
		Assertions.assertNull(intersectionPoints.getIntersectPoints(), "no intersection points");
	}

	@Test
	void test_containment_no_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(20, 20, 50, 50);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);
		Assertions.assertNull(intersectionPoints.getIntersectPoints(), "no intersection points");
	}

	@Test
	void test_adjacency_no_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 20, 90, 100);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);
		Assertions.assertNull(intersectionPoints.getIntersectPoints(), "no intersection points");
	}

	@Test
	void test_normal_no_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(80, 100, 100, 200);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);
		Assertions.assertNull(intersectionPoints.getIntersectPoints(), "no intersection points");
	}

	@Test
	void test_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(50, 50, 100, 200);
		final IntersectionResult intersectionPoints = RectangleAnalyzer
				.findIntersectionPoints(first, second);
		final Point[] intersectPoints = intersectionPoints.getIntersectPoints();
		Assertions.assertNotNull(intersectPoints, "has intersection points");

		Assertions.assertEquals(new Point(50, 90), intersectPoints[0]);
		Assertions.assertEquals(new Point(70, 50), intersectPoints[1]);
	}

	@Test
	void test_containment()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(20, 20, 50, 50);
		Assertions.assertTrue(RectangleAnalyzer.isContainment(first, second));
	}

	@Test
	void test_no_containment_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(20, 20, 100, 100);
		Assertions.assertFalse(RectangleAnalyzer.isContainment(first, second));
	}

	@Test
	void test_no_containment_no_intersection()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(80, 100, 100, 200);
		Assertions.assertFalse(RectangleAnalyzer.isContainment(first, second));
	}

	@Test
	void test_adjacent_sub_line()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 30, 100, 80);
		Assertions.assertTrue(RectangleAnalyzer.isAdjacency(first, second));
	}

	@Test
	void test_adjacent_proper()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 0, 100, 90);
		Assertions.assertTrue(RectangleAnalyzer.isAdjacency(first, second));
	}

	@Test
	void test_adjacent_partial()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(70, 30, 100, 100);
		Assertions.assertTrue(RectangleAnalyzer.isAdjacency(first, second));
	}

	@Test
	void test_no_adjacent()
	{
		final RectangleX first = RectangleX.fromPoints(0, 0, 70, 90);
		final RectangleX second = RectangleX.fromPoints(80, 100, 100, 200);
		Assertions.assertFalse(RectangleAnalyzer.isAdjacency(first, second));
	}
}